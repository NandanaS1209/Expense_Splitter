import java.util.*;
import java.sql.*;
import java.util.UUID;

public class ExpenseSplitterApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Database connection details
        String url = "jdbc:mysql://localhost:3306/expensesplitter";
        String username = "root";
        String password = "PASSWORD"; // <-- Replace with your actual password!

        DatabaseManager db;
        try {
            db = new DatabaseManager(url, username, password);
            System.out.println("✅ Database connected successfully!");
        } catch (SQLException e) {
            System.out.println("❌ Database connection failed: " + e.getMessage());
            System.out.println("Please check your MySQL credentials and ensure MySQL is running.");
            return;
        }

        ExpenseService expenseService = new ExpenseService();

        while (true) {
            System.out.println("\n==== 💰 EXPENSE SPLITTER MENU ====");
            System.out.println("1. 👤 Add User");
            System.out.println("2. 💸 Add Expense");
            System.out.println("3. 👥 View All Users");
            System.out.println("4. 🧾 Show Settlements");
            System.out.println("5. 🚪 Exit");
            System.out.print("Choose an option (1-5): ");

            String choice = scanner.nextLine();

            try {
                switch (choice) {
                    case "1": // Add User
                        System.out.print("Enter user name: ");
                        String name = scanner.nextLine().trim();
                        if (name.isEmpty()) {
                            System.out.println("Name cannot be empty!");
                            break;
                        }
                        String userId = UUID.randomUUID().toString();
                        User user = new User(userId, name);
                        db.addUser(user);
                        System.out.println("✅ User added: " + name);
                        break;

                    case "2": // Add Expense
                        Map<String, User> users = db.getAllUsers();
                        if (users.isEmpty()) {
                            System.out.println("❌ No users found. Please add users first.");
                            break;
                        }

                        // Show available users
                        System.out.println("Available users:");
                        for (User u : users.values()) {
                            System.out.println("- " + u.getName());
                        }

                        System.out.print("Enter payer's name: ");
                        String payerName = scanner.nextLine().trim();
                        User payer = null;
                        for (User u : users.values()) {
                            if (u.getName().equalsIgnoreCase(payerName)) {
                                payer = u;
                                break;
                            }
                        }
                        if (payer == null) {
                            System.out.println("❌ Payer '" + payerName + "' not found. Please add the user first.");
                            break;
                        }

                        System.out.print("Enter expense amount: ₹");
                        double amount;
                        try {
                            amount = Double.parseDouble(scanner.nextLine());
                            if (amount <= 0) {
                                System.out.println("❌ Amount must be positive!");
                                break;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("❌ Invalid amount format!");
                            break;
                        }

                        System.out.print("Enter participant names (comma-separated): ");
                        String[] participantNames = scanner.nextLine().split(",");
                        List<User> participants = new ArrayList<>();
                        for (String pname : participantNames) {
                            pname = pname.trim();
                            for (User u : users.values()) {
                                if (u.getName().equalsIgnoreCase(pname)) {
                                    participants.add(u);
                                    break;
                                }
                            }
                        }
                        if (participants.isEmpty()) {
                            System.out.println("❌ No valid participants found.");
                            break;
                        }

                        Expense expense = new Expense(UUID.randomUUID().toString(), amount, payer);
                        db.addExpense(expense);
                        expenseService.addExpense(payer, amount, participants);
                        System.out.println("✅ Expense added successfully!");
                        System.out.printf("   Payer: %s | Amount: ₹%.2f | Participants: %d%n",
                                payer.getName(), amount, participants.size());
                        break;

                    case "3": // View All Users
                        Map<String, User> allUsers = db.getAllUsers();
                        System.out.println("\n👥 ALL USERS:");
                        if (allUsers.isEmpty()) {
                            System.out.println("No users found.");
                        } else {
                            int count = 1;
                            for (User u : allUsers.values()) {
                                System.out.println(count + ". " + u.getName());
                                count++;
                            }
                        }
                        break;

                    case "4": // Show Settlements
                        expenseService.settleDebts();
                        break;

                    case "5": // Exit
                        System.out.println("👋 Thank you for using Expense Splitter!");
                        return;

                    default:
                        System.out.println("❌ Invalid option. Please choose 1-5.");
                }
            } catch (SQLException e) {
                System.out.println("❌ Database error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("❌ Unexpected error: " + e.getMessage());
            }
        }
    }
}
