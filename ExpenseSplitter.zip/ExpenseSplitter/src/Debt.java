public class Debt {
    private User debtor;
    private User creditor;
    private double amount;

    public Debt(User debtor, User creditor, double amount) {
        this.debtor = debtor;
        this.creditor = creditor;
        this.amount = amount;
    }

    public User getDebtor() { return debtor; }
    public User getCreditor() { return creditor; }
    public double getAmount() { return amount; }
}
