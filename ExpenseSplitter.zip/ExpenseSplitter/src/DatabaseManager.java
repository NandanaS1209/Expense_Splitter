import java.sql.*;
import java.util.*;

public class DatabaseManager {
    private Connection conn;

    public DatabaseManager(String url, String username, String password) throws SQLException {
        conn = DriverManager.getConnection(url, username, password);
    }

    public void addUser(User user) throws SQLException {
        String sql = "INSERT INTO users (id, name) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getId());
            stmt.setString(2, user.getName());
            stmt.executeUpdate();
        }
    }

    public void addExpense(Expense expense) throws SQLException {
        String sql = "INSERT INTO expenses (id, amount, paid_by) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, expense.getId());
            stmt.setDouble(2, expense.getAmount());
            stmt.setString(3, expense.getPaidBy().getId());
            stmt.executeUpdate();
        }
    }

    public Map<String, User> getAllUsers() throws SQLException {
        Map<String, User> users = new HashMap<>();
        String sql = "SELECT * FROM users";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                users.put(rs.getString("id"), new User(rs.getString("id"), rs.getString("name")));
            }
        }
        return users;
    }
}
