import java.util.*;

public class ExpenseService {
    private List<Debt> debts = new ArrayList<>();

    public void addExpense(User paidBy, double amount, List<User> participants) {
        double share = amount / participants.size();
        for (User user : participants) {
            if (!user.getId().equals(paidBy.getId())) {
                debts.add(new Debt(user, paidBy, share));
            }
        }
    }

    public void settleDebts() {
        if (debts.isEmpty()) {
            System.out.println("No settlements to show. Add some expenses first!");
            return;
        }

        // Step 1: Calculate net balances between each pair of people
        Map<String, Map<String, Double>> pairwiseDebts = new HashMap<>();

        for (Debt debt : debts) {
            String debtorId = debt.getDebtor().getId();
            String creditorId = debt.getCreditor().getId();

            // Initialize maps if needed
            pairwiseDebts.putIfAbsent(debtorId, new HashMap<>());
            pairwiseDebts.putIfAbsent(creditorId, new HashMap<>());

            // Add debt from debtor to creditor
            Map<String, Double> debtorOwes = pairwiseDebts.get(debtorId);
            debtorOwes.put(creditorId, debtorOwes.getOrDefault(creditorId, 0.0) + debt.getAmount());
        }

        // Step 2: Net out mutual debts
        Map<String, Map<String, Double>> netDebts = new HashMap<>();
        Set<String> allPeople = new HashSet<>();

        for (String person : pairwiseDebts.keySet()) {
            allPeople.add(person);
            for (String otherPerson : pairwiseDebts.get(person).keySet()) {
                allPeople.add(otherPerson);
            }
        }

        for (String personA : allPeople) {
            for (String personB : allPeople) {
                if (!personA.equals(personB)) {
                    double aOwesB = pairwiseDebts.getOrDefault(personA, new HashMap<>()).getOrDefault(personB, 0.0);
                    double bOwesA = pairwiseDebts.getOrDefault(personB, new HashMap<>()).getOrDefault(personA, 0.0);

                    double netAmount = aOwesB - bOwesA;

                    if (netAmount > 0.01) { // A owes B net amount
                        netDebts.putIfAbsent(personA, new HashMap<>());
                        netDebts.get(personA).put(personB, netAmount);
                    }
                }
            }
        }

        // Step 3: Display optimized settlements
        System.out.println("\n==== OPTIMIZED SETTLEMENTS ====");
        boolean hasSettlements = false;

        for (String debtorId : netDebts.keySet()) {
            for (String creditorId : netDebts.get(debtorId).keySet()) {
                double amount = netDebts.get(debtorId).get(creditorId);

                String debtorName = findUserNameById(debtorId);
                String creditorName = findUserNameById(creditorId);

                System.out.printf("%s owes %s: ₹%.2f%n", debtorName, creditorName, amount);
                hasSettlements = true;
            }
        }

        if (!hasSettlements) {
            System.out.println("All settled! No one owes anyone.");
        }
    }

    // Helper method to get user name from ID
    private String findUserNameById(String userId) {
        for (Debt debt : debts) {
            if (debt.getDebtor().getId().equals(userId)) {
                return debt.getDebtor().getName();
            }
            if (debt.getCreditor().getId().equals(userId)) {
                return debt.getCreditor().getName();
            }
        }
        return userId; // Fallback to ID if name not found
    }
}
