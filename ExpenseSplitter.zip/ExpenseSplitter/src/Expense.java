public class Expense {
    private String id;
    private double amount;
    private User paidBy;

    public Expense(String id, double amount, User paidBy) {
        this.id = id;
        this.amount = amount;
        this.paidBy = paidBy;
    }

    public String getId() { return id; }
    public double getAmount() { return amount; }
    public User getPaidBy() { return paidBy; }
}
